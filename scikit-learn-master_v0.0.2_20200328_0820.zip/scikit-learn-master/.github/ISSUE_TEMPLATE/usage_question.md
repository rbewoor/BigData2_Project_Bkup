---
name: Usage question
about: If you have a usage question
title: ''
labels: Question
assignees: ''

---

<!--
**If your issue is a usage question, please submit it in one of these other channels instead:**
- **StackOverflow with the scikit-learn tag: https://stackoverflow.com/questions/tagged/scikit-learn**
- **Mailing List: https://mail.python.org/mailman/listinfo/scikit-learn**
- **Gitter: https://gitter.im/scikit-learn/scikit-learn**
- **For more information, see User Questions: http://scikit-learn.org/stable/support.html#user-question**

The issue tracker is used only to report issues and feature requests. For
questions, please use either of the above platforms. Most question issues are
closed without an answer on this issue tracker. Thanks for your understanding.
-->
