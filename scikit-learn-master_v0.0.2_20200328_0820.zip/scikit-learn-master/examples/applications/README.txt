.. _realworld_examples:

Examples based on real world datasets
-------------------------------------

Applications to real world problems with some medium sized datasets or
interactive user interface.
