.. _general_examples:

Examples
========

Miscellaneous examples
----------------------

Miscellaneous and introductory examples for scikit-learn.
